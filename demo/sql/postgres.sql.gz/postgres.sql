--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1 (Debian 11.1-1.pgdg90+1)
-- Dumped by pg_dump version 11.1 (Debian 11.1-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: actstream_action; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.actstream_action (
    id integer NOT NULL,
    actor_object_id character varying(255) NOT NULL,
    verb character varying(255) NOT NULL,
    description text,
    target_object_id character varying(255),
    action_object_object_id character varying(255),
    "timestamp" timestamp with time zone NOT NULL,
    public boolean NOT NULL,
    data text,
    action_object_content_type_id integer,
    actor_content_type_id integer NOT NULL,
    target_content_type_id integer
);


ALTER TABLE public.actstream_action OWNER TO ni;

--
-- Name: actstream_action_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.actstream_action_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actstream_action_id_seq OWNER TO ni;

--
-- Name: actstream_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.actstream_action_id_seq OWNED BY public.actstream_action.id;


--
-- Name: actstream_follow; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.actstream_follow (
    id integer NOT NULL,
    object_id character varying(255) NOT NULL,
    actor_only boolean NOT NULL,
    started timestamp with time zone NOT NULL,
    content_type_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.actstream_follow OWNER TO ni;

--
-- Name: actstream_follow_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.actstream_follow_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actstream_follow_id_seq OWNER TO ni;

--
-- Name: actstream_follow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.actstream_follow_id_seq OWNED BY public.actstream_follow.id;


--
-- Name: attachments_attachment; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.attachments_attachment (
    id integer NOT NULL,
    object_id integer NOT NULL,
    attachment_file character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    content_type_id integer NOT NULL,
    creator_id integer NOT NULL,
    CONSTRAINT attachments_attachment_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE public.attachments_attachment OWNER TO ni;

--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.attachments_attachment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attachments_attachment_id_seq OWNER TO ni;

--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.attachments_attachment_id_seq OWNED BY public.attachments_attachment.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO ni;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO ni;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO ni;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO ni;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO ni;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO ni;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO ni;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO ni;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO ni;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO ni;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO ni;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO ni;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO ni;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO ni;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_comment_flags; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_comment_flags (
    id integer NOT NULL,
    flag character varying(30) NOT NULL,
    flag_date timestamp with time zone NOT NULL,
    comment_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.django_comment_flags OWNER TO ni;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.django_comment_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_comment_flags_id_seq OWNER TO ni;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.django_comment_flags_id_seq OWNED BY public.django_comment_flags.id;


--
-- Name: django_comments; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_comments (
    id integer NOT NULL,
    object_pk text NOT NULL,
    user_name character varying(50) NOT NULL,
    user_email character varying(254) NOT NULL,
    user_url character varying(200) NOT NULL,
    comment text NOT NULL,
    submit_date timestamp with time zone NOT NULL,
    ip_address inet,
    is_public boolean NOT NULL,
    is_removed boolean NOT NULL,
    content_type_id integer NOT NULL,
    site_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.django_comments OWNER TO ni;

--
-- Name: django_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.django_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_comments_id_seq OWNER TO ni;

--
-- Name: django_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.django_comments_id_seq OWNED BY public.django_comments.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO ni;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO ni;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_flatpage; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_flatpage (
    id integer NOT NULL,
    url character varying(100) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    enable_comments boolean NOT NULL,
    template_name character varying(70) NOT NULL,
    registration_required boolean NOT NULL
);


ALTER TABLE public.django_flatpage OWNER TO ni;

--
-- Name: django_flatpage_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.django_flatpage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_flatpage_id_seq OWNER TO ni;

--
-- Name: django_flatpage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.django_flatpage_id_seq OWNED BY public.django_flatpage.id;


--
-- Name: django_flatpage_sites; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_flatpage_sites (
    id integer NOT NULL,
    flatpage_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.django_flatpage_sites OWNER TO ni;

--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.django_flatpage_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_flatpage_sites_id_seq OWNER TO ni;

--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.django_flatpage_sites_id_seq OWNED BY public.django_flatpage_sites.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO ni;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO ni;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO ni;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO ni;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO ni;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: dynamic_preferences_globalpreferencemodel; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.dynamic_preferences_globalpreferencemodel (
    id integer NOT NULL,
    section character varying(150),
    name character varying(150) NOT NULL,
    raw_value text
);


ALTER TABLE public.dynamic_preferences_globalpreferencemodel OWNER TO ni;

--
-- Name: dynamic_preferences_globalpreferencemodel_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.dynamic_preferences_globalpreferencemodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dynamic_preferences_globalpreferencemodel_id_seq OWNER TO ni;

--
-- Name: dynamic_preferences_globalpreferencemodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.dynamic_preferences_globalpreferencemodel_id_seq OWNED BY public.dynamic_preferences_globalpreferencemodel.id;


--
-- Name: dynamic_preferences_users_userpreferencemodel; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.dynamic_preferences_users_userpreferencemodel (
    id integer NOT NULL,
    section character varying(150),
    name character varying(150) NOT NULL,
    raw_value text,
    instance_id integer NOT NULL
);


ALTER TABLE public.dynamic_preferences_users_userpreferencemodel OWNER TO ni;

--
-- Name: dynamic_preferences_userpreferencemodel_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.dynamic_preferences_userpreferencemodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dynamic_preferences_userpreferencemodel_id_seq OWNER TO ni;

--
-- Name: dynamic_preferences_userpreferencemodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.dynamic_preferences_userpreferencemodel_id_seq OWNED BY public.dynamic_preferences_users_userpreferencemodel.id;


--
-- Name: nerds_hostusermap; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.nerds_hostusermap (
    id integer NOT NULL,
    domain character varying(255) NOT NULL,
    host_user character varying(255) NOT NULL
);


ALTER TABLE public.nerds_hostusermap OWNER TO ni;

--
-- Name: nerds_hostusermap_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.nerds_hostusermap_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nerds_hostusermap_id_seq OWNER TO ni;

--
-- Name: nerds_hostusermap_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.nerds_hostusermap_id_seq OWNED BY public.nerds_hostusermap.id;


--
-- Name: noclook_choice; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_choice (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    dropdown_id integer NOT NULL
);


ALTER TABLE public.noclook_choice OWNER TO ni;

--
-- Name: noclook_choice_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_choice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_choice_id_seq OWNER TO ni;

--
-- Name: noclook_choice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_choice_id_seq OWNED BY public.noclook_choice.id;


--
-- Name: noclook_dropdown; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_dropdown (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.noclook_dropdown OWNER TO ni;

--
-- Name: noclook_dropdown_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_dropdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_dropdown_id_seq OWNER TO ni;

--
-- Name: noclook_dropdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_dropdown_id_seq OWNED BY public.noclook_dropdown.id;


--
-- Name: noclook_nodehandle; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_nodehandle (
    handle_id integer NOT NULL,
    node_name character varying(200) NOT NULL,
    node_meta_type character varying(255) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    creator_id integer NOT NULL,
    modifier_id integer NOT NULL,
    node_type_id integer NOT NULL
);


ALTER TABLE public.noclook_nodehandle OWNER TO ni;

--
-- Name: noclook_nodehandle_handle_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_nodehandle_handle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_nodehandle_handle_id_seq OWNER TO ni;

--
-- Name: noclook_nodehandle_handle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_nodehandle_handle_id_seq OWNED BY public.noclook_nodehandle.handle_id;


--
-- Name: noclook_nodetype; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_nodetype (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    slug character varying(50) NOT NULL,
    hidden boolean NOT NULL
);


ALTER TABLE public.noclook_nodetype OWNER TO ni;

--
-- Name: noclook_nodetype_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_nodetype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_nodetype_id_seq OWNER TO ni;

--
-- Name: noclook_nodetype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_nodetype_id_seq OWNED BY public.noclook_nodetype.id;


--
-- Name: noclook_nordunetuniqueid; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_nordunetuniqueid (
    id integer NOT NULL,
    unique_id character varying(256) NOT NULL,
    reserved boolean NOT NULL,
    reserve_message character varying(512),
    created timestamp with time zone NOT NULL,
    reserver_id integer,
    site_id integer
);


ALTER TABLE public.noclook_nordunetuniqueid OWNER TO ni;

--
-- Name: noclook_nordunetuniqueid_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_nordunetuniqueid_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_nordunetuniqueid_id_seq OWNER TO ni;

--
-- Name: noclook_nordunetuniqueid_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_nordunetuniqueid_id_seq OWNED BY public.noclook_nordunetuniqueid.id;


--
-- Name: noclook_opticalnodetype; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_opticalnodetype (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.noclook_opticalnodetype OWNER TO ni;

--
-- Name: noclook_opticalnodetype_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_opticalnodetype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_opticalnodetype_id_seq OWNER TO ni;

--
-- Name: noclook_opticalnodetype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_opticalnodetype_id_seq OWNED BY public.noclook_opticalnodetype.id;


--
-- Name: noclook_serviceclass; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_serviceclass (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.noclook_serviceclass OWNER TO ni;

--
-- Name: noclook_serviceclass_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_serviceclass_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_serviceclass_id_seq OWNER TO ni;

--
-- Name: noclook_serviceclass_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_serviceclass_id_seq OWNED BY public.noclook_serviceclass.id;


--
-- Name: noclook_servicetype; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_servicetype (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    service_class_id integer NOT NULL
);


ALTER TABLE public.noclook_servicetype OWNER TO ni;

--
-- Name: noclook_servicetype_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_servicetype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_servicetype_id_seq OWNER TO ni;

--
-- Name: noclook_servicetype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_servicetype_id_seq OWNED BY public.noclook_servicetype.id;


--
-- Name: noclook_uniqueidgenerator; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.noclook_uniqueidgenerator (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    base_id integer NOT NULL,
    zfill boolean NOT NULL,
    base_id_length integer NOT NULL,
    prefix character varying(256),
    suffix character varying(256),
    last_id character varying(256) NOT NULL,
    next_id character varying(256) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    creator_id integer NOT NULL,
    modifier_id integer
);


ALTER TABLE public.noclook_uniqueidgenerator OWNER TO ni;

--
-- Name: noclook_uniqueidgenerator_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.noclook_uniqueidgenerator_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.noclook_uniqueidgenerator_id_seq OWNER TO ni;

--
-- Name: noclook_uniqueidgenerator_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.noclook_uniqueidgenerator_id_seq OWNED BY public.noclook_uniqueidgenerator.id;


--
-- Name: scan_queueitem; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.scan_queueitem (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    data text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.scan_queueitem OWNER TO ni;

--
-- Name: scan_queueitem_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.scan_queueitem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scan_queueitem_id_seq OWNER TO ni;

--
-- Name: scan_queueitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.scan_queueitem_id_seq OWNED BY public.scan_queueitem.id;


--
-- Name: tastypie_apiaccess; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.tastypie_apiaccess (
    id integer NOT NULL,
    identifier character varying(255) NOT NULL,
    url text NOT NULL,
    request_method character varying(10) NOT NULL,
    accessed integer NOT NULL,
    CONSTRAINT tastypie_apiaccess_accessed_check CHECK ((accessed >= 0))
);


ALTER TABLE public.tastypie_apiaccess OWNER TO ni;

--
-- Name: tastypie_apiaccess_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.tastypie_apiaccess_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tastypie_apiaccess_id_seq OWNER TO ni;

--
-- Name: tastypie_apiaccess_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.tastypie_apiaccess_id_seq OWNED BY public.tastypie_apiaccess.id;


--
-- Name: tastypie_apikey; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.tastypie_apikey (
    id integer NOT NULL,
    key character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.tastypie_apikey OWNER TO ni;

--
-- Name: tastypie_apikey_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.tastypie_apikey_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tastypie_apikey_id_seq OWNER TO ni;

--
-- Name: tastypie_apikey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.tastypie_apikey_id_seq OWNED BY public.tastypie_apikey.id;


--
-- Name: userprofile_userprofile; Type: TABLE; Schema: public; Owner: ni
--

CREATE TABLE public.userprofile_userprofile (
    id integer NOT NULL,
    display_name character varying(255),
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.userprofile_userprofile OWNER TO ni;

--
-- Name: userprofile_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: ni
--

CREATE SEQUENCE public.userprofile_userprofile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userprofile_userprofile_id_seq OWNER TO ni;

--
-- Name: userprofile_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ni
--

ALTER SEQUENCE public.userprofile_userprofile_id_seq OWNED BY public.userprofile_userprofile.id;


--
-- Name: actstream_action id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_action ALTER COLUMN id SET DEFAULT nextval('public.actstream_action_id_seq'::regclass);


--
-- Name: actstream_follow id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_follow ALTER COLUMN id SET DEFAULT nextval('public.actstream_follow_id_seq'::regclass);


--
-- Name: attachments_attachment id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.attachments_attachment ALTER COLUMN id SET DEFAULT nextval('public.attachments_attachment_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_comment_flags id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comment_flags ALTER COLUMN id SET DEFAULT nextval('public.django_comment_flags_id_seq'::regclass);


--
-- Name: django_comments id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comments ALTER COLUMN id SET DEFAULT nextval('public.django_comments_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_flatpage id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_flatpage ALTER COLUMN id SET DEFAULT nextval('public.django_flatpage_id_seq'::regclass);


--
-- Name: django_flatpage_sites id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_flatpage_sites ALTER COLUMN id SET DEFAULT nextval('public.django_flatpage_sites_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: dynamic_preferences_globalpreferencemodel id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.dynamic_preferences_globalpreferencemodel ALTER COLUMN id SET DEFAULT nextval('public.dynamic_preferences_globalpreferencemodel_id_seq'::regclass);


--
-- Name: dynamic_preferences_users_userpreferencemodel id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.dynamic_preferences_users_userpreferencemodel ALTER COLUMN id SET DEFAULT nextval('public.dynamic_preferences_userpreferencemodel_id_seq'::regclass);


--
-- Name: nerds_hostusermap id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.nerds_hostusermap ALTER COLUMN id SET DEFAULT nextval('public.nerds_hostusermap_id_seq'::regclass);


--
-- Name: noclook_choice id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_choice ALTER COLUMN id SET DEFAULT nextval('public.noclook_choice_id_seq'::regclass);


--
-- Name: noclook_dropdown id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_dropdown ALTER COLUMN id SET DEFAULT nextval('public.noclook_dropdown_id_seq'::regclass);


--
-- Name: noclook_nodehandle handle_id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodehandle ALTER COLUMN handle_id SET DEFAULT nextval('public.noclook_nodehandle_handle_id_seq'::regclass);


--
-- Name: noclook_nodetype id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodetype ALTER COLUMN id SET DEFAULT nextval('public.noclook_nodetype_id_seq'::regclass);


--
-- Name: noclook_nordunetuniqueid id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nordunetuniqueid ALTER COLUMN id SET DEFAULT nextval('public.noclook_nordunetuniqueid_id_seq'::regclass);


--
-- Name: noclook_opticalnodetype id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_opticalnodetype ALTER COLUMN id SET DEFAULT nextval('public.noclook_opticalnodetype_id_seq'::regclass);


--
-- Name: noclook_serviceclass id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_serviceclass ALTER COLUMN id SET DEFAULT nextval('public.noclook_serviceclass_id_seq'::regclass);


--
-- Name: noclook_servicetype id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_servicetype ALTER COLUMN id SET DEFAULT nextval('public.noclook_servicetype_id_seq'::regclass);


--
-- Name: noclook_uniqueidgenerator id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_uniqueidgenerator ALTER COLUMN id SET DEFAULT nextval('public.noclook_uniqueidgenerator_id_seq'::regclass);


--
-- Name: scan_queueitem id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.scan_queueitem ALTER COLUMN id SET DEFAULT nextval('public.scan_queueitem_id_seq'::regclass);


--
-- Name: tastypie_apiaccess id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.tastypie_apiaccess ALTER COLUMN id SET DEFAULT nextval('public.tastypie_apiaccess_id_seq'::regclass);


--
-- Name: tastypie_apikey id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.tastypie_apikey ALTER COLUMN id SET DEFAULT nextval('public.tastypie_apikey_id_seq'::regclass);


--
-- Name: userprofile_userprofile id; Type: DEFAULT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.userprofile_userprofile ALTER COLUMN id SET DEFAULT nextval('public.userprofile_userprofile_id_seq'::regclass);


--
-- Data for Name: actstream_action; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.actstream_action (id, actor_object_id, verb, description, target_object_id, action_object_object_id, "timestamp", public, data, action_object_content_type_id, actor_content_type_id, target_content_type_id) FROM stdin;
1	1	create	\N	\N	1	2019-01-23 13:09:00.629572+00	t	{"noclook": {"action_type": "node"}}	18	3	\N
2	1	create	\N	\N	2	2019-01-23 13:09:19.28202+00	t	{"noclook": {"action_type": "node"}}	18	3	\N
3	1	update	\N	\N	2	2019-01-23 13:09:19.371731+00	t	{"noclook": {"action_type": "node_property", "property": "cable_type", "value_before": "", "value_after": "Dark Fiber"}}	18	3	\N
4	1	update	\N	\N	2	2019-01-23 13:09:19.40065+00	t	{"noclook": {"action_type": "node_property", "property": "description", "value_before": "", "value_after": "test cable"}}	18	3	\N
5	1	create	\N	2	1	2019-01-23 13:09:19.814132+00	t	{"noclook": {"action_type": "relationship", "relationship_type": "Provides"}}	18	3	18
\.


--
-- Data for Name: actstream_follow; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.actstream_follow (id, object_id, actor_only, started, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: attachments_attachment; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.attachments_attachment (id, object_id, attachment_file, created, modified, content_type_id, creator_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add user	3	add_user
8	Can change user	3	change_user
9	Can delete user	3	delete_user
10	Can add content type	4	add_contenttype
11	Can change content type	4	change_contenttype
12	Can delete content type	4	delete_contenttype
13	Can add session	5	add_session
14	Can change session	5	change_session
15	Can delete session	5	delete_session
16	Can add site	6	add_site
17	Can change site	6	change_site
18	Can delete site	6	delete_site
19	Can add flat page	7	add_flatpage
20	Can change flat page	7	change_flatpage
21	Can delete flat page	7	delete_flatpage
22	Can add log entry	8	add_logentry
23	Can change log entry	8	change_logentry
24	Can delete log entry	8	delete_logentry
25	Can add api access	9	add_apiaccess
26	Can change api access	9	change_apiaccess
27	Can delete api access	9	delete_apiaccess
28	Can add api key	10	add_apikey
29	Can change api key	10	change_apikey
30	Can delete api key	10	delete_apikey
31	Can add action	11	add_action
32	Can change action	11	change_action
33	Can delete action	11	delete_action
34	Can add follow	12	add_follow
35	Can change follow	12	change_follow
36	Can delete follow	12	delete_follow
37	Can add comment	13	add_comment
38	Can change comment	13	change_comment
39	Can delete comment	13	delete_comment
40	Can moderate comments	13	can_moderate
41	Can add comment flag	14	add_commentflag
42	Can change comment flag	14	change_commentflag
43	Can delete comment flag	14	delete_commentflag
44	Can add global preference	15	add_globalpreferencemodel
45	Can change global preference	15	change_globalpreferencemodel
46	Can delete global preference	15	delete_globalpreferencemodel
47	Can add attachment	16	add_attachment
48	Can change attachment	16	change_attachment
49	Can delete attachment	16	delete_attachment
50	Can delete foreign attachments	16	delete_foreign_attachments
51	Can add user profile	17	add_userprofile
52	Can change user profile	17	change_userprofile
53	Can delete user profile	17	delete_userprofile
54	Can add node handle	18	add_nodehandle
55	Can change node handle	18	change_nodehandle
56	Can delete node handle	18	delete_nodehandle
57	Can add node type	19	add_nodetype
58	Can change node type	19	change_nodetype
59	Can delete node type	19	delete_nodetype
60	Can add nordunet unique id	20	add_nordunetuniqueid
61	Can change nordunet unique id	20	change_nordunetuniqueid
62	Can delete nordunet unique id	20	delete_nordunetuniqueid
63	Can add unique id generator	21	add_uniqueidgenerator
64	Can change unique id generator	21	change_uniqueidgenerator
65	Can delete unique id generator	21	delete_uniqueidgenerator
66	Can add optical node type	22	add_opticalnodetype
67	Can change optical node type	22	change_opticalnodetype
68	Can delete optical node type	22	delete_opticalnodetype
69	Can add service class	23	add_serviceclass
70	Can change service class	23	change_serviceclass
71	Can delete service class	23	delete_serviceclass
72	Can add service type	24	add_servicetype
73	Can change service type	24	change_servicetype
74	Can delete service type	24	delete_servicetype
75	Can add choice	25	add_choice
76	Can change choice	25	change_choice
77	Can delete choice	25	delete_choice
78	Can add dropdown	26	add_dropdown
79	Can change dropdown	26	change_dropdown
80	Can delete dropdown	26	delete_dropdown
81	Can add queue item	27	add_queueitem
82	Can change queue item	27	change_queueitem
83	Can delete queue item	27	delete_queueitem
84	Can add host user map	28	add_hostusermap
85	Can change host user map	28	change_hostusermap
86	Can delete host user map	28	delete_hostusermap
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$36000$3qyVfruB67Wt$5AHAt/gtKPkJc8p99YZ0s+3hVT8aWd8nXNSVzQqq4gI=	2019-01-23 13:36:07.242143+00	t	admin				t	t	2019-01-23 10:50:01.427812+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2019-01-23 10:52:47.747705+00	1	Host	1	[{"added": {}}]	19	1
2	2019-01-23 10:53:00.780444+00	2	Host User	1	[{"added": {}}]	19	1
3	2019-01-23 10:53:12.730177+00	3	External Equipment	1	[{"added": {}}]	19	1
4	2019-01-23 10:53:20.791209+00	4	End User	1	[{"added": {}}]	19	1
5	2019-01-23 10:53:30.19519+00	5	Peering Partner	1	[{"added": {}}]	19	1
6	2019-01-23 10:53:37.3923+00	6	Peering Group	1	[{"added": {}}]	19	1
7	2019-01-23 10:53:49.458958+00	7	Unit	1	[{"added": {}}]	19	1
8	2019-01-23 10:53:57.388145+00	8	Site	1	[{"added": {}}]	19	1
9	2019-01-23 10:54:05.807682+00	9	Customer	1	[{"added": {}}]	19	1
10	2019-01-23 10:54:16.799236+00	10	ODF	1	[{"added": {}}]	19	1
11	2019-01-23 10:54:28.086819+00	11	Port	1	[{"added": {}}]	19	1
12	2019-01-23 10:54:38.002776+00	12	Router	1	[{"added": {}}]	19	1
13	2019-01-23 10:54:46.534505+00	13	Optical Multiplex Section	1	[{"added": {}}]	19	1
14	2019-01-23 10:54:54.017508+00	14	Optical Link	1	[{"added": {}}]	19	1
15	2019-01-23 10:55:01.506718+00	15	Optical Path	1	[{"added": {}}]	19	1
16	2019-01-23 10:55:08.414568+00	16	Service	1	[{"added": {}}]	19	1
17	2019-01-23 10:55:17.031988+00	17	Cable	1	[{"added": {}}]	19	1
18	2019-01-23 10:55:24.241031+00	18	Provider	1	[{"added": {}}]	19	1
19	2019-01-23 10:55:32.368663+00	19	Optical Node	1	[{"added": {}}]	19	1
20	2019-01-23 10:55:39.48623+00	20	Rack	1	[{"added": {}}]	19	1
21	2019-01-23 10:55:46.571305+00	21	Site Owner	1	[{"added": {}}]	19	1
22	2019-01-23 10:57:08.746065+00	2	Adva FSP3000R7	1	[{"added": {}}]	22	1
23	2019-01-23 10:57:53.508791+00	1	Silver	1	[{"added": {}}]	23	1
24	2019-01-23 10:58:02.457512+00	2	Gold	1	[{"added": {}}]	23	1
25	2019-01-23 10:58:11.054644+00	3	Platinum	1	[{"added": {}}]	23	1
26	2019-01-23 10:58:18.203597+00	4	DWDM	1	[{"added": {}}]	23	1
27	2019-01-23 10:58:25.414742+00	5	MPLS	1	[{"added": {}}]	23	1
28	2019-01-23 10:58:32.864149+00	6	IP	1	[{"added": {}}]	23	1
29	2019-01-23 10:58:39.793212+00	7	Internal	1	[{"added": {}}]	23	1
30	2019-01-23 10:58:46.262515+00	8	External	1	[{"added": {}}]	23	1
31	2019-01-23 10:59:37.974954+00	1	Backbone	1	[{"added": {}}]	24	1
32	2019-01-23 10:59:57.078993+00	2	DWDM	1	[{"added": {}}]	24	1
33	2019-01-23 11:00:10.279205+00	3	Ethernet	1	[{"added": {}}]	24	1
34	2019-01-23 11:00:47.053069+00	4	eduID	1	[{"added": {}}]	24	1
35	2019-01-23 11:00:59.181413+00	5	L2C	1	[{"added": {}}]	24	1
36	2019-01-23 11:01:14.356186+00	6	IX	1	[{"added": {}}]	24	1
37	2019-01-23 11:01:20.487078+00	7	PNI	1	[{"added": {}}]	24	1
38	2019-01-23 11:01:31.463234+00	8	Customer Connection	1	[{"added": {}}]	24	1
39	2019-01-23 11:01:48.269642+00	9	External	1	[{"added": {}}]	24	1
40	2019-01-23 11:02:48.281958+00	1	sunet_cable_id	1	[{"added": {}}]	21	1
41	2019-01-23 11:03:31.805003+00	2	sunet_optical_path_id	1	[{"added": {}}]	21	1
42	2019-01-23 11:03:51.710009+00	1	sunet_cable_id	2	[{"changed": {"fields": ["base_id_length", "prefix"]}}]	21	1
43	2019-01-23 11:04:36.210931+00	3	sunet_optical_link_id	1	[{"added": {}}]	21	1
44	2019-01-23 11:05:07.400555+00	4	sunet_service_id	1	[{"added": {}}]	21	1
45	2019-01-23 11:05:58.278715+00	5	GlobalPreferenceModel - id_generators/services	2	[{"changed": {"fields": ["raw_value"]}}]	15	1
46	2019-01-23 11:06:20.558315+00	1	GlobalPreferenceModel - general/data_domain	2	[{"changed": {"fields": ["raw_value"]}}]	15	1
47	2019-01-23 11:06:49.509003+00	3	GlobalPreferenceModel - announcements/page_flash_message	2	[{"changed": {"fields": ["raw_value"]}}]	15	1
\.


--
-- Data for Name: django_comment_flags; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_comment_flags (id, flag, flag_date, comment_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_comments; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_comments (id, object_pk, user_name, user_email, user_url, comment, submit_date, ip_address, is_public, is_removed, content_type_id, site_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	auth	user
4	contenttypes	contenttype
5	sessions	session
6	sites	site
7	flatpages	flatpage
8	admin	logentry
9	tastypie	apiaccess
10	tastypie	apikey
11	actstream	action
12	actstream	follow
13	django_comments	comment
14	django_comments	commentflag
15	dynamic_preferences	globalpreferencemodel
16	attachments	attachment
17	userprofile	userprofile
18	noclook	nodehandle
19	noclook	nodetype
20	noclook	nordunetuniqueid
21	noclook	uniqueidgenerator
22	noclook	opticalnodetype
23	noclook	serviceclass
24	noclook	servicetype
25	noclook	choice
26	noclook	dropdown
27	scan	queueitem
28	nerds	hostusermap
\.


--
-- Data for Name: django_flatpage; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_flatpage (id, url, title, content, enable_comments, template_name, registration_required) FROM stdin;
\.


--
-- Data for Name: django_flatpage_sites; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_flatpage_sites (id, flatpage_id, site_id) FROM stdin;
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2019-01-22 16:42:53.404513+00
2	auth	0001_initial	2019-01-22 16:42:53.545246+00
3	actstream	0001_initial	2019-01-22 16:42:53.69596+00
4	actstream	0002_remove_action_data	2019-01-22 16:42:53.701908+00
5	admin	0001_initial	2019-01-22 16:42:53.745683+00
6	admin	0002_logentry_remove_auto_add	2019-01-22 16:42:53.75992+00
7	attachments	0001_initial	2019-01-22 16:42:53.792143+00
8	attachments	0002_auto_20180104_1247	2019-01-22 16:42:53.809325+00
9	contenttypes	0002_remove_content_type_name	2019-01-22 16:42:53.851093+00
10	auth	0002_alter_permission_name_max_length	2019-01-22 16:42:53.862559+00
11	auth	0003_alter_user_email_max_length	2019-01-22 16:42:53.880415+00
12	auth	0004_alter_user_username_opts	2019-01-22 16:42:53.895489+00
13	auth	0005_alter_user_last_login_null	2019-01-22 16:42:53.919092+00
14	auth	0006_require_contenttypes_0002	2019-01-22 16:42:53.922795+00
15	auth	0007_alter_validators_add_error_messages	2019-01-22 16:42:53.962307+00
16	auth	0008_alter_user_username_max_length	2019-01-22 16:42:53.982317+00
17	sites	0001_initial	2019-01-22 16:42:53.995625+00
18	django_comments	0001_initial	2019-01-22 16:42:54.098298+00
19	django_comments	0002_update_user_email_field_length	2019-01-22 16:42:54.118711+00
20	django_comments	0003_add_submit_date_index	2019-01-22 16:42:54.144739+00
21	dynamic_preferences	0001_initial	2019-01-22 16:42:54.253194+00
22	dynamic_preferences	0002_auto_20150712_0332	2019-01-22 16:42:54.311379+00
23	dynamic_preferences	0003_auto_20151223_1407	2019-01-22 16:42:54.345538+00
24	dynamic_preferences	0004_move_user_model	2019-01-22 16:42:54.364987+00
25	flatpages	0001_initial	2019-01-22 16:42:54.430868+00
26	noclook	0001_initial	2019-01-22 16:42:54.623043+00
27	noclook	0002_nodetype_hidden	2019-01-22 16:42:54.633981+00
28	nerds	0001_initial	2019-01-22 16:42:54.662136+00
29	nerds	0002_load_initial_host_user_map	2019-01-22 16:42:54.710029+00
30	noclook	0003_opticalnodetype	2019-01-22 16:42:54.751423+00
31	noclook	0004_serviceclass_servicetype	2019-01-22 16:42:54.799609+00
32	noclook	0005_auto_20170612_1543	2019-01-22 16:42:54.847436+00
33	noclook	0006_default_dropdowns	2019-01-22 16:42:54.994477+00
34	scan	0001_initial	2019-01-22 16:42:55.013367+00
35	sessions	0001_initial	2019-01-22 16:42:55.042295+00
36	sites	0002_alter_domain_unique	2019-01-22 16:42:55.064933+00
37	tastypie	0001_initial	2019-01-22 16:42:55.128069+00
38	tastypie	0002_api_access_url_length	2019-01-22 16:42:55.136808+00
39	userprofile	0001_initial	2019-01-22 16:42:55.174662+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
h2w4g47bcjkb1owe04n4pe2ap2dgzba4	NGY1ZTdjM2ZiNTc0NGFmOTAwNWFlZjYzMGZlZjgzODc0YzFiNTA0ZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjAzOGQyZjU0MWEwNWE0NzkyZmUxYzIyZTg2OWU1ODQzMmE0OTAxNDAiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-02-06 13:36:07.250372+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Data for Name: dynamic_preferences_globalpreferencemodel; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.dynamic_preferences_globalpreferencemodel (id, section, name, raw_value) FROM stdin;
2	general	more_info_link	https://portal.nordu.net/display/nordunetops/
4	announcements	page_flash_message_level	info
5	id_generators	services	sunet_service_id
1	general	data_domain	sunet
3	announcements	page_flash_message	Demo
\.


--
-- Data for Name: dynamic_preferences_users_userpreferencemodel; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.dynamic_preferences_users_userpreferencemodel (id, section, name, raw_value, instance_id) FROM stdin;
\.


--
-- Data for Name: nerds_hostusermap; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.nerds_hostusermap (id, domain, host_user) FROM stdin;
1	sunet.se	SUNET
2	eduroam.se	SUNET
3	eduid.se	SUNET
4	eid2.se	SUNET
5	lobber.se	SUNET
6	skolfederation.se	SUNET
7	swami.se	SUNET
8	swamid.se	SUNET
9	nordu.net	NORDUnet
10	nordunet.tv	NORDUnet
11	nunoc.org	NORDUnet
12	nunoc.se	NORDUnet
13	funet.fi	FUNET
14	uninett.no	UNINETT
15	rhnet.is	RHnet
16	ndgf.org	NDGF
17	wayf.dk	WAYF
\.


--
-- Data for Name: noclook_choice; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_choice (id, name, value, dropdown_id) FROM stdin;
1	ciena6500	ciena6500	2
2	Dark Fiber	Dark Fiber	3
3	Patch	Patch	3
4	Power Cable	Power Cable	3
5	C13 / C14	C13 / C14	4
6	C19 / C20	C19 / C20	4
7	CEE	CEE	4
8	E2000	E2000	4
9	Fixed	Fixed	4
10	LC	LC	4
11	MU	MU	4
12	RJ45	RJ45	4
13	SC	SC	4
14	Schuko	Schuko	4
15	In service	In service	5
16	Reserved	Reserved	5
17	Decommissioned	Decommissioned	5
18	Testing	Testing	5
19	OTS	OTS	6
20	OPS	OPS	6
21	WDM	WDM	7
22	10Gb	10Gb	8
23	100Gb	100Gb	8
24	WDM	WDM	9
25	1	1	10
26	2	2	10
27	3	3	10
28	4	4	10
29	DEV	DEV	11
30	NOC	NOC	11
31	Manual	Manual	12
32	Puppet	Puppet	12
33	Belgium	BE	13
34	Switzerland	CH	13
35	Germany	DE	13
36	Denmark	DK	13
37	Finland	FI	13
38	France	FR	13
39	Iceland	IS	13
40	Netherlands	NL	13
41	Norway	NO	13
42	Sweden	SE	13
43	United Kingdom	UK	13
44	USA	US	13
\.


--
-- Data for Name: noclook_dropdown; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_dropdown (id, name) FROM stdin;
1	site_types
2	optical_node_types
3	cable_types
4	port_types
5	operational_states
6	optical_link_types
7	optical_path_framing
8	optical_path_capacity
9	optical_link_interface_type
10	security_classes
11	responsible_groups
12	host_management_sw
13	countries
\.


--
-- Data for Name: noclook_nodehandle; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_nodehandle (handle_id, node_name, node_meta_type, created, modified, creator_id, modifier_id, node_type_id) FROM stdin;
1	Sunet	Relation	2019-01-23 13:09:00.202168+00	2019-01-23 13:09:19.761781+00	1	1	18
2	test	Physical	2019-01-23 13:09:19.228206+00	2019-01-23 13:09:19.795592+00	1	1	17
\.


--
-- Data for Name: noclook_nodetype; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_nodetype (id, type, slug, hidden) FROM stdin;
1	Host	host	f
2	Host User	host-user	f
3	External Equipment	external-equipment	f
4	End User	end-user	f
5	Peering Partner	peering-partner	f
6	Peering Group	peering-group	f
7	Unit	unit	t
8	Site	site	f
9	Customer	customer	f
10	ODF	odf	f
11	Port	port	t
12	Router	router	f
13	Optical Multiplex Section	optical-multiplex-section	f
14	Optical Link	optical-link	f
15	Optical Path	optical-path	f
16	Service	service	f
17	Cable	cable	f
18	Provider	provider	f
19	Optical Node	optical-node	f
20	Rack	rack	f
21	Site Owner	site-owner	f
\.


--
-- Data for Name: noclook_nordunetuniqueid; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_nordunetuniqueid (id, unique_id, reserved, reserve_message, created, reserver_id, site_id) FROM stdin;
\.


--
-- Data for Name: noclook_opticalnodetype; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_opticalnodetype (id, name) FROM stdin;
1	ciena6500
2	Adva FSP3000R7
\.


--
-- Data for Name: noclook_serviceclass; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_serviceclass (id, name) FROM stdin;
1	Silver
2	Gold
3	Platinum
4	DWDM
5	MPLS
6	IP
7	Internal
8	External
\.


--
-- Data for Name: noclook_servicetype; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_servicetype (id, name, service_class_id) FROM stdin;
1	Backbone	6
2	DWDM	4
3	Ethernet	4
4	eduID	3
5	L2C	5
6	IX	6
7	PNI	6
8	Customer Connection	6
9	External	8
\.


--
-- Data for Name: noclook_uniqueidgenerator; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.noclook_uniqueidgenerator (id, name, base_id, zfill, base_id_length, prefix, suffix, last_id, next_id, created, modified, creator_id, modifier_id) FROM stdin;
2	sunet_optical_path_id	1	t	6	PREFIX-4	\N		PREFIX-4000001	2019-01-23 11:03:31.798689+00	2019-01-23 11:03:31.798715+00	1	\N
1	sunet_cable_id	1	t	6	PREFIX-0	\N		PREFIX-0000001	2019-01-23 11:02:48.274447+00	2019-01-23 11:03:51.704719+00	1	\N
3	sunet_optical_link_id	1	t	6	PREFIX-1	\N		PREFIX-1000001	2019-01-23 11:04:36.204172+00	2019-01-23 11:04:36.204191+00	1	\N
4	sunet_service_id	1	t	6	PREFIX-S	\N		PREFIX-S000001	2019-01-23 11:05:07.391795+00	2019-01-23 11:05:07.391821+00	1	\N
\.


--
-- Data for Name: scan_queueitem; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.scan_queueitem (id, type, status, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tastypie_apiaccess; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.tastypie_apiaccess (id, identifier, url, request_method, accessed) FROM stdin;
\.


--
-- Data for Name: tastypie_apikey; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.tastypie_apikey (id, key, created, user_id) FROM stdin;
\.


--
-- Data for Name: userprofile_userprofile; Type: TABLE DATA; Schema: public; Owner: ni
--

COPY public.userprofile_userprofile (id, display_name, created, modified, user_id) FROM stdin;
1	\N	2019-01-23 10:50:01.470056+00	2019-01-23 10:50:01.470083+00	1
\.


--
-- Name: actstream_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.actstream_action_id_seq', 5, true);


--
-- Name: actstream_follow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.actstream_follow_id_seq', 1, false);


--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.attachments_attachment_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 86, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 47, true);


--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.django_comment_flags_id_seq', 1, false);


--
-- Name: django_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.django_comments_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 28, true);


--
-- Name: django_flatpage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.django_flatpage_id_seq', 1, false);


--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.django_flatpage_sites_id_seq', 1, false);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 39, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: dynamic_preferences_globalpreferencemodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.dynamic_preferences_globalpreferencemodel_id_seq', 5, true);


--
-- Name: dynamic_preferences_userpreferencemodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.dynamic_preferences_userpreferencemodel_id_seq', 1, false);


--
-- Name: nerds_hostusermap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.nerds_hostusermap_id_seq', 17, true);


--
-- Name: noclook_choice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_choice_id_seq', 44, true);


--
-- Name: noclook_dropdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_dropdown_id_seq', 13, true);


--
-- Name: noclook_nodehandle_handle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_nodehandle_handle_id_seq', 2, true);


--
-- Name: noclook_nodetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_nodetype_id_seq', 21, true);


--
-- Name: noclook_nordunetuniqueid_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_nordunetuniqueid_id_seq', 1, false);


--
-- Name: noclook_opticalnodetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_opticalnodetype_id_seq', 2, true);


--
-- Name: noclook_serviceclass_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_serviceclass_id_seq', 8, true);


--
-- Name: noclook_servicetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_servicetype_id_seq', 9, true);


--
-- Name: noclook_uniqueidgenerator_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.noclook_uniqueidgenerator_id_seq', 4, true);


--
-- Name: scan_queueitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.scan_queueitem_id_seq', 1, false);


--
-- Name: tastypie_apiaccess_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.tastypie_apiaccess_id_seq', 1, false);


--
-- Name: tastypie_apikey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.tastypie_apikey_id_seq', 1, false);


--
-- Name: userprofile_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ni
--

SELECT pg_catalog.setval('public.userprofile_userprofile_id_seq', 1, true);


--
-- Name: actstream_action actstream_action_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_action
    ADD CONSTRAINT actstream_action_pkey PRIMARY KEY (id);


--
-- Name: actstream_follow actstream_follow_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_follow
    ADD CONSTRAINT actstream_follow_pkey PRIMARY KEY (id);


--
-- Name: actstream_follow actstream_follow_user_id_content_type_id__63ca7c27_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_follow
    ADD CONSTRAINT actstream_follow_user_id_content_type_id__63ca7c27_uniq UNIQUE (user_id, content_type_id, object_id);


--
-- Name: attachments_attachment attachments_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachment_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags django_comment_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags django_comment_flags_user_id_comment_id_flag_537f77a7_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_comment_id_flag_537f77a7_uniq UNIQUE (user_id, comment_id, flag);


--
-- Name: django_comments django_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_flatpage django_flatpage_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_flatpage
    ADD CONSTRAINT django_flatpage_pkey PRIMARY KEY (id);


--
-- Name: django_flatpage_sites django_flatpage_sites_flatpage_id_site_id_0d29d9d1_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_flatpage_id_site_id_0d29d9d1_uniq UNIQUE (flatpage_id, site_id);


--
-- Name: django_flatpage_sites django_flatpage_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: dynamic_preferences_globalpreferencemodel dynamic_preferences_glob_section_name_f4a2439b_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.dynamic_preferences_globalpreferencemodel
    ADD CONSTRAINT dynamic_preferences_glob_section_name_f4a2439b_uniq UNIQUE (section, name);


--
-- Name: dynamic_preferences_globalpreferencemodel dynamic_preferences_globalpreferencemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.dynamic_preferences_globalpreferencemodel
    ADD CONSTRAINT dynamic_preferences_globalpreferencemodel_pkey PRIMARY KEY (id);


--
-- Name: dynamic_preferences_users_userpreferencemodel dynamic_preferences_user_instance_id_section_name_620205bb_uniq; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.dynamic_preferences_users_userpreferencemodel
    ADD CONSTRAINT dynamic_preferences_user_instance_id_section_name_620205bb_uniq UNIQUE (instance_id, section, name);


--
-- Name: dynamic_preferences_users_userpreferencemodel dynamic_preferences_userpreferencemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.dynamic_preferences_users_userpreferencemodel
    ADD CONSTRAINT dynamic_preferences_userpreferencemodel_pkey PRIMARY KEY (id);


--
-- Name: nerds_hostusermap nerds_hostusermap_domain_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.nerds_hostusermap
    ADD CONSTRAINT nerds_hostusermap_domain_key UNIQUE (domain);


--
-- Name: nerds_hostusermap nerds_hostusermap_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.nerds_hostusermap
    ADD CONSTRAINT nerds_hostusermap_pkey PRIMARY KEY (id);


--
-- Name: noclook_choice noclook_choice_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_choice
    ADD CONSTRAINT noclook_choice_pkey PRIMARY KEY (id);


--
-- Name: noclook_dropdown noclook_dropdown_name_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_dropdown
    ADD CONSTRAINT noclook_dropdown_name_key UNIQUE (name);


--
-- Name: noclook_dropdown noclook_dropdown_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_dropdown
    ADD CONSTRAINT noclook_dropdown_pkey PRIMARY KEY (id);


--
-- Name: noclook_nodehandle noclook_nodehandle_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodehandle
    ADD CONSTRAINT noclook_nodehandle_pkey PRIMARY KEY (handle_id);


--
-- Name: noclook_nodetype noclook_nodetype_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodetype
    ADD CONSTRAINT noclook_nodetype_pkey PRIMARY KEY (id);


--
-- Name: noclook_nodetype noclook_nodetype_slug_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodetype
    ADD CONSTRAINT noclook_nodetype_slug_key UNIQUE (slug);


--
-- Name: noclook_nodetype noclook_nodetype_type_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodetype
    ADD CONSTRAINT noclook_nodetype_type_key UNIQUE (type);


--
-- Name: noclook_nordunetuniqueid noclook_nordunetuniqueid_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nordunetuniqueid
    ADD CONSTRAINT noclook_nordunetuniqueid_pkey PRIMARY KEY (id);


--
-- Name: noclook_nordunetuniqueid noclook_nordunetuniqueid_unique_id_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nordunetuniqueid
    ADD CONSTRAINT noclook_nordunetuniqueid_unique_id_key UNIQUE (unique_id);


--
-- Name: noclook_opticalnodetype noclook_opticalnodetype_name_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_opticalnodetype
    ADD CONSTRAINT noclook_opticalnodetype_name_key UNIQUE (name);


--
-- Name: noclook_opticalnodetype noclook_opticalnodetype_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_opticalnodetype
    ADD CONSTRAINT noclook_opticalnodetype_pkey PRIMARY KEY (id);


--
-- Name: noclook_serviceclass noclook_serviceclass_name_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_serviceclass
    ADD CONSTRAINT noclook_serviceclass_name_key UNIQUE (name);


--
-- Name: noclook_serviceclass noclook_serviceclass_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_serviceclass
    ADD CONSTRAINT noclook_serviceclass_pkey PRIMARY KEY (id);


--
-- Name: noclook_servicetype noclook_servicetype_name_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_servicetype
    ADD CONSTRAINT noclook_servicetype_name_key UNIQUE (name);


--
-- Name: noclook_servicetype noclook_servicetype_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_servicetype
    ADD CONSTRAINT noclook_servicetype_pkey PRIMARY KEY (id);


--
-- Name: noclook_uniqueidgenerator noclook_uniqueidgenerator_name_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_uniqueidgenerator
    ADD CONSTRAINT noclook_uniqueidgenerator_name_key UNIQUE (name);


--
-- Name: noclook_uniqueidgenerator noclook_uniqueidgenerator_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_uniqueidgenerator
    ADD CONSTRAINT noclook_uniqueidgenerator_pkey PRIMARY KEY (id);


--
-- Name: scan_queueitem scan_queueitem_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.scan_queueitem
    ADD CONSTRAINT scan_queueitem_pkey PRIMARY KEY (id);


--
-- Name: tastypie_apiaccess tastypie_apiaccess_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.tastypie_apiaccess
    ADD CONSTRAINT tastypie_apiaccess_pkey PRIMARY KEY (id);


--
-- Name: tastypie_apikey tastypie_apikey_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.tastypie_apikey
    ADD CONSTRAINT tastypie_apikey_pkey PRIMARY KEY (id);


--
-- Name: tastypie_apikey tastypie_apikey_user_id_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.tastypie_apikey
    ADD CONSTRAINT tastypie_apikey_user_id_key UNIQUE (user_id);


--
-- Name: userprofile_userprofile userprofile_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.userprofile_userprofile
    ADD CONSTRAINT userprofile_userprofile_pkey PRIMARY KEY (id);


--
-- Name: userprofile_userprofile userprofile_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.userprofile_userprofile
    ADD CONSTRAINT userprofile_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: actstream_action_action_object_content_type_id_ee623c15; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_action_object_content_type_id_ee623c15 ON public.actstream_action USING btree (action_object_content_type_id);


--
-- Name: actstream_action_action_object_object_id_6433bdf7; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_action_object_object_id_6433bdf7 ON public.actstream_action USING btree (action_object_object_id);


--
-- Name: actstream_action_action_object_object_id_6433bdf7_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_action_object_object_id_6433bdf7_like ON public.actstream_action USING btree (action_object_object_id varchar_pattern_ops);


--
-- Name: actstream_action_actor_content_type_id_d5e5ec2a; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_actor_content_type_id_d5e5ec2a ON public.actstream_action USING btree (actor_content_type_id);


--
-- Name: actstream_action_actor_object_id_72ef0cfa; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_actor_object_id_72ef0cfa ON public.actstream_action USING btree (actor_object_id);


--
-- Name: actstream_action_actor_object_id_72ef0cfa_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_actor_object_id_72ef0cfa_like ON public.actstream_action USING btree (actor_object_id varchar_pattern_ops);


--
-- Name: actstream_action_public_ac0653e9; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_public_ac0653e9 ON public.actstream_action USING btree (public);


--
-- Name: actstream_action_target_content_type_id_187fa164; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_target_content_type_id_187fa164 ON public.actstream_action USING btree (target_content_type_id);


--
-- Name: actstream_action_target_object_id_e080d801; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_target_object_id_e080d801 ON public.actstream_action USING btree (target_object_id);


--
-- Name: actstream_action_target_object_id_e080d801_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_target_object_id_e080d801_like ON public.actstream_action USING btree (target_object_id varchar_pattern_ops);


--
-- Name: actstream_action_timestamp_a23fe3ae; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_timestamp_a23fe3ae ON public.actstream_action USING btree ("timestamp");


--
-- Name: actstream_action_verb_83f768b7; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_verb_83f768b7 ON public.actstream_action USING btree (verb);


--
-- Name: actstream_action_verb_83f768b7_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_action_verb_83f768b7_like ON public.actstream_action USING btree (verb varchar_pattern_ops);


--
-- Name: actstream_follow_content_type_id_ba287eb9; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_follow_content_type_id_ba287eb9 ON public.actstream_follow USING btree (content_type_id);


--
-- Name: actstream_follow_object_id_d790e00d; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_follow_object_id_d790e00d ON public.actstream_follow USING btree (object_id);


--
-- Name: actstream_follow_object_id_d790e00d_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_follow_object_id_d790e00d_like ON public.actstream_follow USING btree (object_id varchar_pattern_ops);


--
-- Name: actstream_follow_started_254c63bd; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_follow_started_254c63bd ON public.actstream_follow USING btree (started);


--
-- Name: actstream_follow_user_id_e9d4e1ff; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX actstream_follow_user_id_e9d4e1ff ON public.actstream_follow USING btree (user_id);


--
-- Name: attachments_attachment_content_type_id_35dd9d5d; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX attachments_attachment_content_type_id_35dd9d5d ON public.attachments_attachment USING btree (content_type_id);


--
-- Name: attachments_attachment_creator_id_d471ef83; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX attachments_attachment_creator_id_d471ef83 ON public.attachments_attachment USING btree (creator_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_comment_flags_comment_id_d8054933; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_comment_flags_comment_id_d8054933 ON public.django_comment_flags USING btree (comment_id);


--
-- Name: django_comment_flags_flag_8b141fcb; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_comment_flags_flag_8b141fcb ON public.django_comment_flags USING btree (flag);


--
-- Name: django_comment_flags_flag_8b141fcb_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_comment_flags_flag_8b141fcb_like ON public.django_comment_flags USING btree (flag varchar_pattern_ops);


--
-- Name: django_comment_flags_user_id_f3f81f0a; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_comment_flags_user_id_f3f81f0a ON public.django_comment_flags USING btree (user_id);


--
-- Name: django_comments_content_type_id_c4afe962; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_comments_content_type_id_c4afe962 ON public.django_comments USING btree (content_type_id);


--
-- Name: django_comments_site_id_9dcf666e; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_comments_site_id_9dcf666e ON public.django_comments USING btree (site_id);


--
-- Name: django_comments_submit_date_514ed2d9; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_comments_submit_date_514ed2d9 ON public.django_comments USING btree (submit_date);


--
-- Name: django_comments_user_id_a0a440a1; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_comments_user_id_a0a440a1 ON public.django_comments USING btree (user_id);


--
-- Name: django_flatpage_sites_flatpage_id_078bbc8b; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_flatpage_sites_flatpage_id_078bbc8b ON public.django_flatpage_sites USING btree (flatpage_id);


--
-- Name: django_flatpage_sites_site_id_bfd8ea84; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_flatpage_sites_site_id_bfd8ea84 ON public.django_flatpage_sites USING btree (site_id);


--
-- Name: django_flatpage_url_41612362; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_flatpage_url_41612362 ON public.django_flatpage USING btree (url);


--
-- Name: django_flatpage_url_41612362_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_flatpage_url_41612362_like ON public.django_flatpage USING btree (url varchar_pattern_ops);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: dynamic_preferences_globalpreferencemodel_name_033debe0; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_globalpreferencemodel_name_033debe0 ON public.dynamic_preferences_globalpreferencemodel USING btree (name);


--
-- Name: dynamic_preferences_globalpreferencemodel_name_033debe0_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_globalpreferencemodel_name_033debe0_like ON public.dynamic_preferences_globalpreferencemodel USING btree (name varchar_pattern_ops);


--
-- Name: dynamic_preferences_globalpreferencemodel_section_c1ee9cc3; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_globalpreferencemodel_section_c1ee9cc3 ON public.dynamic_preferences_globalpreferencemodel USING btree (section);


--
-- Name: dynamic_preferences_globalpreferencemodel_section_c1ee9cc3_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_globalpreferencemodel_section_c1ee9cc3_like ON public.dynamic_preferences_globalpreferencemodel USING btree (section varchar_pattern_ops);


--
-- Name: dynamic_preferences_userpreferencemodel_instance_id_299d62f6; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_userpreferencemodel_instance_id_299d62f6 ON public.dynamic_preferences_users_userpreferencemodel USING btree (instance_id);


--
-- Name: dynamic_preferences_userpreferencemodel_name_84a43a22; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_userpreferencemodel_name_84a43a22 ON public.dynamic_preferences_users_userpreferencemodel USING btree (name);


--
-- Name: dynamic_preferences_userpreferencemodel_name_84a43a22_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_userpreferencemodel_name_84a43a22_like ON public.dynamic_preferences_users_userpreferencemodel USING btree (name varchar_pattern_ops);


--
-- Name: dynamic_preferences_userpreferencemodel_section_710d9e2a; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_userpreferencemodel_section_710d9e2a ON public.dynamic_preferences_users_userpreferencemodel USING btree (section);


--
-- Name: dynamic_preferences_userpreferencemodel_section_710d9e2a_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX dynamic_preferences_userpreferencemodel_section_710d9e2a_like ON public.dynamic_preferences_users_userpreferencemodel USING btree (section varchar_pattern_ops);


--
-- Name: nerds_hostusermap_domain_87cdbee8_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX nerds_hostusermap_domain_87cdbee8_like ON public.nerds_hostusermap USING btree (domain varchar_pattern_ops);


--
-- Name: noclook_choice_dropdown_id_98571179; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_choice_dropdown_id_98571179 ON public.noclook_choice USING btree (dropdown_id);


--
-- Name: noclook_dropdown_name_05a3c2c6_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_dropdown_name_05a3c2c6_like ON public.noclook_dropdown USING btree (name varchar_pattern_ops);


--
-- Name: noclook_nodehandle_creator_id_8baa9c6e; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_nodehandle_creator_id_8baa9c6e ON public.noclook_nodehandle USING btree (creator_id);


--
-- Name: noclook_nodehandle_modifier_id_a800a6af; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_nodehandle_modifier_id_a800a6af ON public.noclook_nodehandle USING btree (modifier_id);


--
-- Name: noclook_nodehandle_node_type_id_b16e22da; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_nodehandle_node_type_id_b16e22da ON public.noclook_nodehandle USING btree (node_type_id);


--
-- Name: noclook_nodetype_slug_7b0ef2e3_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_nodetype_slug_7b0ef2e3_like ON public.noclook_nodetype USING btree (slug varchar_pattern_ops);


--
-- Name: noclook_nodetype_type_707682c6_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_nodetype_type_707682c6_like ON public.noclook_nodetype USING btree (type varchar_pattern_ops);


--
-- Name: noclook_nordunetuniqueid_reserver_id_2ecd8c69; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_nordunetuniqueid_reserver_id_2ecd8c69 ON public.noclook_nordunetuniqueid USING btree (reserver_id);


--
-- Name: noclook_nordunetuniqueid_site_id_10ce2137; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_nordunetuniqueid_site_id_10ce2137 ON public.noclook_nordunetuniqueid USING btree (site_id);


--
-- Name: noclook_nordunetuniqueid_unique_id_1985c452_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_nordunetuniqueid_unique_id_1985c452_like ON public.noclook_nordunetuniqueid USING btree (unique_id varchar_pattern_ops);


--
-- Name: noclook_opticalnodetype_name_87c96bd2_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_opticalnodetype_name_87c96bd2_like ON public.noclook_opticalnodetype USING btree (name varchar_pattern_ops);


--
-- Name: noclook_serviceclass_name_c98b90bb_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_serviceclass_name_c98b90bb_like ON public.noclook_serviceclass USING btree (name varchar_pattern_ops);


--
-- Name: noclook_servicetype_name_3cfab447_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_servicetype_name_3cfab447_like ON public.noclook_servicetype USING btree (name varchar_pattern_ops);


--
-- Name: noclook_servicetype_service_class_id_a8921f00; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_servicetype_service_class_id_a8921f00 ON public.noclook_servicetype USING btree (service_class_id);


--
-- Name: noclook_uniqueidgenerator_creator_id_ff31cace; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_uniqueidgenerator_creator_id_ff31cace ON public.noclook_uniqueidgenerator USING btree (creator_id);


--
-- Name: noclook_uniqueidgenerator_modifier_id_6b4ee962; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_uniqueidgenerator_modifier_id_6b4ee962 ON public.noclook_uniqueidgenerator USING btree (modifier_id);


--
-- Name: noclook_uniqueidgenerator_name_0320db3d_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX noclook_uniqueidgenerator_name_0320db3d_like ON public.noclook_uniqueidgenerator USING btree (name varchar_pattern_ops);


--
-- Name: tastypie_apikey_key_17b411bb; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX tastypie_apikey_key_17b411bb ON public.tastypie_apikey USING btree (key);


--
-- Name: tastypie_apikey_key_17b411bb_like; Type: INDEX; Schema: public; Owner: ni
--

CREATE INDEX tastypie_apikey_key_17b411bb_like ON public.tastypie_apikey USING btree (key varchar_pattern_ops);


--
-- Name: actstream_action actstream_action_action_object_conten_ee623c15_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_action
    ADD CONSTRAINT actstream_action_action_object_conten_ee623c15_fk_django_co FOREIGN KEY (action_object_content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: actstream_action actstream_action_actor_content_type_i_d5e5ec2a_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_action
    ADD CONSTRAINT actstream_action_actor_content_type_i_d5e5ec2a_fk_django_co FOREIGN KEY (actor_content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: actstream_action actstream_action_target_content_type__187fa164_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_action
    ADD CONSTRAINT actstream_action_target_content_type__187fa164_fk_django_co FOREIGN KEY (target_content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: actstream_follow actstream_follow_content_type_id_ba287eb9_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_follow
    ADD CONSTRAINT actstream_follow_content_type_id_ba287eb9_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: actstream_follow actstream_follow_user_id_e9d4e1ff_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.actstream_follow
    ADD CONSTRAINT actstream_follow_user_id_e9d4e1ff_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachme_content_type_id_35dd9d5d_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachme_content_type_id_35dd9d5d_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachment_creator_id_d471ef83_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachment_creator_id_d471ef83_fk_auth_user_id FOREIGN KEY (creator_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags django_comment_flags_comment_id_d8054933_fk_django_comments_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_comment_id_d8054933_fk_django_comments_id FOREIGN KEY (comment_id) REFERENCES public.django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags django_comment_flags_user_id_f3f81f0a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_f3f81f0a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments django_comments_content_type_id_c4afe962_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_content_type_id_c4afe962_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments django_comments_site_id_9dcf666e_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_site_id_9dcf666e_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments django_comments_user_id_a0a440a1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_user_id_a0a440a1_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_flatpage_sites django_flatpage_site_flatpage_id_078bbc8b_fk_django_fl; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_flatpage_sites
    ADD CONSTRAINT django_flatpage_site_flatpage_id_078bbc8b_fk_django_fl FOREIGN KEY (flatpage_id) REFERENCES public.django_flatpage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_flatpage_sites django_flatpage_sites_site_id_bfd8ea84_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_site_id_bfd8ea84_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dynamic_preferences_users_userpreferencemodel dynamic_preferences__instance_id_299d62f6_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.dynamic_preferences_users_userpreferencemodel
    ADD CONSTRAINT dynamic_preferences__instance_id_299d62f6_fk_auth_user FOREIGN KEY (instance_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_choice noclook_choice_dropdown_id_98571179_fk_noclook_dropdown_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_choice
    ADD CONSTRAINT noclook_choice_dropdown_id_98571179_fk_noclook_dropdown_id FOREIGN KEY (dropdown_id) REFERENCES public.noclook_dropdown(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_nodehandle noclook_nodehandle_creator_id_8baa9c6e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodehandle
    ADD CONSTRAINT noclook_nodehandle_creator_id_8baa9c6e_fk_auth_user_id FOREIGN KEY (creator_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_nodehandle noclook_nodehandle_modifier_id_a800a6af_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodehandle
    ADD CONSTRAINT noclook_nodehandle_modifier_id_a800a6af_fk_auth_user_id FOREIGN KEY (modifier_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_nodehandle noclook_nodehandle_node_type_id_b16e22da_fk_noclook_nodetype_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nodehandle
    ADD CONSTRAINT noclook_nodehandle_node_type_id_b16e22da_fk_noclook_nodetype_id FOREIGN KEY (node_type_id) REFERENCES public.noclook_nodetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_nordunetuniqueid noclook_nordunetuniq_site_id_10ce2137_fk_noclook_n; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nordunetuniqueid
    ADD CONSTRAINT noclook_nordunetuniq_site_id_10ce2137_fk_noclook_n FOREIGN KEY (site_id) REFERENCES public.noclook_nodehandle(handle_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_nordunetuniqueid noclook_nordunetuniqueid_reserver_id_2ecd8c69_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_nordunetuniqueid
    ADD CONSTRAINT noclook_nordunetuniqueid_reserver_id_2ecd8c69_fk_auth_user_id FOREIGN KEY (reserver_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_servicetype noclook_servicetype_service_class_id_a8921f00_fk_noclook_s; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_servicetype
    ADD CONSTRAINT noclook_servicetype_service_class_id_a8921f00_fk_noclook_s FOREIGN KEY (service_class_id) REFERENCES public.noclook_serviceclass(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_uniqueidgenerator noclook_uniqueidgenerator_creator_id_ff31cace_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_uniqueidgenerator
    ADD CONSTRAINT noclook_uniqueidgenerator_creator_id_ff31cace_fk_auth_user_id FOREIGN KEY (creator_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: noclook_uniqueidgenerator noclook_uniqueidgenerator_modifier_id_6b4ee962_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.noclook_uniqueidgenerator
    ADD CONSTRAINT noclook_uniqueidgenerator_modifier_id_6b4ee962_fk_auth_user_id FOREIGN KEY (modifier_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tastypie_apikey tastypie_apikey_user_id_8c8fa920_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.tastypie_apikey
    ADD CONSTRAINT tastypie_apikey_user_id_8c8fa920_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: userprofile_userprofile userprofile_userprofile_user_id_59dda034_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ni
--

ALTER TABLE ONLY public.userprofile_userprofile
    ADD CONSTRAINT userprofile_userprofile_user_id_59dda034_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

